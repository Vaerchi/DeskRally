DeskRally installation

Extract all files, then double-click DeskRallySetup.exe. Approve permanent access only for a support provider you trust. Windows will ask for administrator approval.

This private bundle can enroll ONE computer in the selected account and expires 15 minutes after it was prepared. Do not post it publicly. Download a fresh bundle if it expires. Delete the ZIP and extracted files after installation.

Before approving the Windows administrator prompt, check that it names the publisher your support provider told you to expect.
